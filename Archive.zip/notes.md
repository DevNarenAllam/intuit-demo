# Problem statement

ORM SQL databases
Validations -> Pydantic + SQLAlchemy = sqlmodel
Logging - Observability
Security -> JWR TokenBased Authentication, Encryption 
            -> IAM - Authorization

API - testing, end-to-end
Performance -> Asynchronous

Scalability -> 


