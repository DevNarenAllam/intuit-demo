#!/bin/bash
fastapi run /app/IntakeService/main.py --port=$PORT --host=0.0.0.0